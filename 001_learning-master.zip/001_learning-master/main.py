import func_def


def main():
    func_def.learn_str_func(False)
    func_def.learn_number_func(False)
    func_def.learn_list_tuple_set_func(False)
    func_def.learn_dictionary_func(False)
    func_def.learn_if_elif_else(False)
    func_def.learn_loops(True)


print(__name__)
main()
